namespace HRConnect.Api.DTOs
{
  public class ForgotPasswordDto
  {
    public string Email { get; set; } = string.Empty;
  }
}